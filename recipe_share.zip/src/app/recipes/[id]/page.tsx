'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Cookies from 'js-cookie';

interface Recipe {
  _id: string;
  title: string;
  image: string;
  description: string;
  category: string;
  tags: string[];
  likes: string[];
  favorites: string[];
}

export default function RecipeDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const [recipe, setRecipe] = useState<Recipe | null>(null);

  useEffect(() => {
    const fetchRecipe = async () => {
      const res = await fetch(`/api/recipes/${id}`);
      if (!res.ok) return router.push('/recipes');
      const data = await res.json();
      setRecipe(data);
    };
    fetchRecipe();
  }, [id, router]);

  const handleLike = async () => {
    const token = Cookies.get('token');
    if (!token) return alert('Login required!');
    await fetch(`/api/recipes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ action: 'like' }),
    });
    location.reload();
  };

  const handleFavorite = async () => {
    const token = Cookies.get('token');
    if (!token) return alert('Login required!');
    await fetch(`/api/recipes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ action: 'favorite' }),
    });
    location.reload();
  };

  const handleShare = () => {
    const url = `${window.location.origin}/recipes/${id}`;
    navigator.clipboard.writeText(url);
    alert('Link copied to clipboard!');
  };

  if (!recipe) return <p className="p-8">Loading...</p>;

  return (
    <main className="max-w-3xl mx-auto p-6">
      <img src={recipe.image} alt={recipe.title} className="w-full h-64 object-cover rounded mb-4" />
      <h1 className="text-3xl font-bold mb-2">{recipe.title}</h1>
      <p className="text-gray-400 mb-1">{recipe.category}</p>

      <div className="flex gap-2 mb-4 flex-wrap">
        {recipe.tags.map((tag, i) => (
          <span key={i} className="bg-green-100 px-2 py-1 text-sm rounded text-green-700">{tag}</span>
        ))}
      </div>

      <div className="flex gap-4 mb-6">
        <button onClick={handleLike} className="bg-pink-500 text-white px-4 py-2 rounded hover:bg-pink-600">❤️ Like</button>
        <button onClick={handleFavorite} className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">📌 Save</button>
        <button onClick={handleShare} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">🔗 Share</button>
      </div>

      <p className="text-lg text-gray-700 dark:text-gray-200 leading-relaxed">{recipe.description}</p>
    </main>
  );
}
