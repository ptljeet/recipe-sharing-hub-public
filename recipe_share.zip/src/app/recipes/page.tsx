'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

interface Recipe {
  _id: string;
  title: string;
  image: string;
  category: string;
  tags: string[];
}

export default function RecipesPage() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    fetch('/api/recipes')
      .then((res) => res.json())
      .then((data) => setRecipes(data));
  }, []);

  const filtered = recipes.filter((r) =>
    r.title.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <main className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">🍱 All Recipes</h1>

      <input
        type="text"
        placeholder="Search recipes..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="w-full p-2 mb-6 border rounded text-white"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((recipe) => (
          <Link key={recipe._id} href={`/recipes/${recipe._id}`}>
            <div className="bg-white dark:bg-gray-800 p-4 rounded shadow hover:shadow-lg transition cursor-pointer">
              <img
                src={recipe.image}
                alt={recipe.title}
                className="w-full h-40 object-cover rounded mb-2"
              />
              <h2 className="text-xl font-semibold">{recipe.title}</h2>
              <p className="text-sm text-gray-500">{recipe.category}</p>
              <div className="flex flex-wrap gap-1 mt-1 text-sm text-green-700">
                {recipe.tags?.map((tag, i) => (
                  <span key={i} className="bg-green-100 px-2 py-0.5 rounded">{tag}</span>
                ))}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
