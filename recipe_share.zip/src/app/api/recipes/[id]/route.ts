import { connectDB } from '@/lib/mongodb';
import Recipe from '@/models/Recipe';
import { NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';

export async function GET(
  req: Request,
  context: { params?: { id?: string } }
) {
  await connectDB();

  const id = context?.params?.id;
  if (!id) {
    return NextResponse.json({ error: 'Missing recipe ID' }, { status: 400 });
  }

  try {
    const recipe = await Recipe.findById(id);
    if (!recipe) {
      return NextResponse.json({ error: 'Recipe not found' }, { status: 404 });
    }
    return NextResponse.json(recipe);
  } catch (err) {
    return NextResponse.json({ error: 'Invalid recipe ID' }, { status: 400 });
  }
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  await connectDB();
  const token = req.headers.get('authorization')?.split(' ')[1];
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { action } = await req.json(); // like | favorite
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as { userId: string };
    const recipe = await Recipe.findById(params.id);

    if (!recipe) return NextResponse.json({ error: 'Recipe not found' }, { status: 404 });

    if (action === 'like') {
      if (recipe.likes.includes(decoded.userId)) {
        recipe.likes.pull(decoded.userId);
      } else {
        recipe.likes.push(decoded.userId);
      }
    } else if (action === 'favorite') {
      if (recipe.favorites.includes(decoded.userId)) {
        recipe.favorites.pull(decoded.userId);
      } else {
        recipe.favorites.push(decoded.userId);
      }
    }

    await recipe.save();
    return NextResponse.json({ message: 'Updated successfully', likes: recipe.likes.length, favorites: recipe.favorites.length });
  } catch (err) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
}