'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Cookies from 'js-cookie';
import jwt from 'jsonwebtoken';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';

interface TokenPayload {
  userId: string;
}
interface Recipe {
  _id: string;
  title: string;
  image: string;
  category: string;
}

export default function DashboardPage() {
  const [userId, setUserId] = useState<string | null>(null);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const router = useRouter();
  const {user}=useAuth();

  useEffect(() => {
    const token = Cookies.get('token');
    if (!token) {
      router.push('/login');
      return;
    }

    try {
      const decoded = jwt.decode(token) as TokenPayload;
      setUserId(decoded?.userId || null);
    } catch (err) {
      Cookies.remove('token');
      router.push('/login');
    }
  }, [router]);

  useEffect(() => {
    if (!user) router.push('/login');

    fetch('/api/recipes')
      .then((res) => res.json())
      .then((data) => setRecipes(data.slice(0, 6))); // get first 6 for preview
  }, []);

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-2 text-green-600">Welcome to your Dashboard 🎉</h1>
      <p className="text-gray-500 mb-6">
        Your User ID: <span className="font-mono text-blue-500">{userId}</span>
      </p>

      <div className="mb-4 flex justify-between items-center">
        <h2 className="text-xl font-semibold">Explore New Recipes</h2>
        <Link href="/recipes" className="text-sm text-blue-600 hover:underline">View All</Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {recipes.map((r) => (
          <Link href={`/recipes/${r._id}`} key={r._id}>
            <div className="bg-white dark:bg-gray-800 p-4 rounded shadow hover:shadow-md transition cursor-pointer">
              <img
                src={r.image}
                alt={r.title}
                className="w-full h-40 object-cover rounded mb-2"
              />
              <h3 className="text-lg font-semibold">{r.title}</h3>
              <p className="text-sm text-gray-500">{r.category}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
