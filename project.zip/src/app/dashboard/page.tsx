'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import RecipeCard from '@/components/RecipeCard';

interface Recipe {
  _id: string;
  title: string;
  image: string;
  category: string;
  tags: string[];
  description: string;
  createdAt: string;
  authorId?: string;
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFavorites = async () => {
      try {
        const res = await fetch(`/api/users/${user?.userId}/favorites`);
        if (!res.ok) {
          throw new Error('Failed to fetch favorites');
          
        }
        const data = await res.json();
        setRecipes(data);
      } catch (error) {
        console.error('Failed to fetch user favorites:', error);
      } finally {
        setLoading(false);
      }
    };

    if (user?.userId) {
      fetchFavorites();
    }
  }, [user]);

  if (!user?.userId) {
    return (
      <div className="p-6 text-center">
        <h1 className="text-2xl font-semibold">Please login to view your dashboard</h1>
      </div>
    );
  }

  return (
    <main className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">📋 My Saved Recipes</h1>

      {loading ? (
        <p className="text-center">Loading...</p>
      ) : recipes.length === 0 ? (
        <p className="text-center text-gray-400">No saved recipes yet.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe) => (
            <RecipeCard key={recipe._id} recipe={recipe} />
          ))}
        </div>
      )}
    </main>
  );
}
