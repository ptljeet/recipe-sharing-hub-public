import { cookies } from 'next/headers';
import jwt from 'jsonwebtoken';
import { connectDB } from '@/lib/mongodb';
import Favourite from '@/models/Favourites';
import Recipe from '@/models/Recipe';

export default async function SavedPage() {
  await connectDB();
  const cookieStore = await cookies();
  const token = cookieStore.get('token')?.value;
  const decoded: any = jwt.decode(token || '');
  const userId = decoded?.userId;

  const favs = await Favourite.find({ userId });
  const recipeIds = favs.map((f: any) => f.recipeId);
  const savedRecipes = await Recipe.find({ _id: { $in: recipeIds } });

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Saved Recipes</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {savedRecipes.map((recipe: any) => (
          <div key={recipe._id} className="border p-4 rounded shadow">
            <h2 className="font-semibold text-lg">{recipe.title}</h2>
            <p>{recipe.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
