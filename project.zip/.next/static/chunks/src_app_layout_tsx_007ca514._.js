(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_next_dist_compiled_crypto-browserify_index_07270ec0.js",
  "static/chunks/node_modules_next_dist_compiled_da909a55._.js",
  "static/chunks/node_modules_next_dist_a02d7e9f._.js",
  "static/chunks/node_modules_next_navigation_ff30cc2f.js",
  "static/chunks/node_modules_8039108b._.js",
  "static/chunks/src_aa0d225f._.js"
],
    source: "dynamic"
});
